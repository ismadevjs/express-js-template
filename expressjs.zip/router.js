const express = require('express')
const router = express.Router()
const userController = require('./controller/userController')
const instructorController = require('./controller/instructorController')
const backendController = require('./controller/backendController')
const middleware = require('./middleware/auth')
const multer = require('multer')
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads')
    },
    filename: function (req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now())
    }
  })  
const upload = multer({ storage: storage })
// frontend area
router.get('/', userController.index)
router.get('/signup', middleware.user_cannot_auth, userController.register)
router.post('/signup', middleware.user_cannot_auth, userController.register_post)
router.get('/login', middleware.user_cannot_auth, userController.login)
router.post('/login', middleware.user_cannot_auth,userController.login_post)

// instructor area 
router.get('/instructor', middleware.user_auth, instructorController.instructor)
router.get('/instructor/courses', middleware.user_auth, instructorController.courses)
// general logout
router.get('/logout', middleware.user_auth, userController.signout)

//backend  area 

router.get('/admin/register', middleware.cannot_auth, backendController.register)
router.post('/admin/register', middleware.cannot_auth, backendController.register_post)
router.get('/admin/login', middleware.cannot_auth, backendController.login)
router.post('/admin/login', middleware.cannot_auth, backendController.login_post)
router.get('/admin', middleware.is_auth, backendController.index)
router.get('/admin/categories', middleware.is_auth, backendController.categories)
router.post('/admin/categories', middleware.is_auth, backendController.categories_post)
router.get('/admin/categories/:id/delete', middleware.is_auth, backendController.categories_delete)
router.post('/admin/categories/:id/edit', middleware.is_auth, backendController.categories_edit)
router.post('/admin/categories/bulk_del', middleware.is_auth, backendController.categories_bulk_delete)
router.get('/admin/categories/del_all', middleware.is_auth, backendController.categories_delete_all)
router.post('/admin/categories/sub/add', middleware.is_auth, backendController.categories_sub_add)
router.get('/admin/categories/:id/sub/:slug/delete', backendController.categories_sub_delete)
router.get('/admin/logout', middleware.is_auth, backendController.signout)
router.get('/admin/slider', middleware.is_auth, backendController.slider)
router.post('/admin/slider', middleware.is_auth, backendController.slider_post)
router.post('/admin/slider_background', middleware.is_auth, upload.single('model_img'), backendController.slider_background)
router.post('/admin/slider_background_image', middleware.is_auth, upload.single('bg_img'), backendController.slider_background_image)
router.get('/admin/infos', middleware.is_auth, backendController.infos)
router.post('/admin/infos', middleware.is_auth, backendController.infos_post)
router.post('/admin/infos/:id/edit', middleware.is_auth, backendController.infos_post_edit)
router.post('/admin/infos/:id/delete', middleware.is_auth, backendController.infos_post_delete)
router.get('/admin/pages', middleware.is_auth, backendController.pages)
router.post('/admin/pages', middleware.is_auth, backendController.pages_add)
router.get('/admin/pages/:slug/edit', middleware.is_auth, backendController.pages_edit_get)
router.post('/admin/pages/:slug/edit', middleware.is_auth, backendController.pages_edit)
router.get('/admin/page/:slug/delete', middleware.is_auth, backendController.pages_delete)
router.get('/admin/socialnetwork', middleware.is_auth, backendController.socialnetwork)
router.post('/admin/socialnetwork', middleware.is_auth, backendController.socialnetwork_post)
router.post('/admin/socialnetwork/:id/edit', middleware.is_auth, backendController.socialnetwork_post_update)
router.post('/admin/socialnetwork/:id/delete', middleware.is_auth, backendController.socialnetwork_post_delete)
router.get('/admin/testimonial', middleware.is_auth, backendController.testimonial)
router.post('/admin/testimonial', middleware.is_auth, upload.single('avatar'),backendController.testimonial_post)
router.post('/admin/testimonial/:id/edit', middleware.is_auth, upload.single('avatar'),backendController.testimonial_post_edit)
router.post('/admin/testimonial/:id/delete', middleware.is_auth, backendController.testimonial_post_delete)
router.get('/admin/settings', middleware.is_auth, backendController.settings)
module.exports = router